# 用户档案 — profile.md

```yaml
# 基本信息
platforms: []           # 常用平台：抖音 / 小红书 / 微信视频号
account_type: ""        # 个人号 / 企业号（蓝V/机构认证）
industry: ""           # 行业/领域
business_model: ""     # 商业模式：带货 / 卖课 / 接广 / 引流 / 无

# 改法偏好
repair_preference: ""  # 用户偏好的改稿风格（如：偏保守 / 偏自由 / 保留口语化）

# 账号信息
account_notes: ""      # 其他备注
```
